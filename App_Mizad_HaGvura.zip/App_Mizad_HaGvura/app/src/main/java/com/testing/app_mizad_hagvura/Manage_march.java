package com.testing.app_mizad_hagvura;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Manage_march extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_march);
    }
}
